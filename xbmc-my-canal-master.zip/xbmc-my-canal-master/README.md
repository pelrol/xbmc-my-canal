xbmc-my-canal
=============

XBMC french canal+ replay addon
